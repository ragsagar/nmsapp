from setuptools import setup

setup(name='nmsapp',
      version='0.1',
      packages=['nms'],
      include_package_data=True,
      description='Nms django app',
      url='http://deam.ae',
      author='Alya Alshamsi, Rag Sagar.V',
      author_email='alya@deam.ae, rsagar@deam.ae',)
